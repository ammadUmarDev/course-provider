import { Course } from './Course';

export const COURSES: Course[] = [
  // {
  //   id: 1,
  //   name: 'Frontend Development: VueJS',
  //   level: 'Intermediate',
  //   language: 'English',
  //   rating: 4,
  // },
  // {
  //   id: 2,
  //   name: 'Frontend Development: ReactJS',
  //   level: 'Intermediate',
  //   language: 'English',
  //   rating: 5,
  // },
  // {
  //   id: 3,
  //   name: 'Frontend Development: AngularJS',
  //   level: 'Intermediate',
  //   language: 'English',
  //   rating: 4,
  // },
];